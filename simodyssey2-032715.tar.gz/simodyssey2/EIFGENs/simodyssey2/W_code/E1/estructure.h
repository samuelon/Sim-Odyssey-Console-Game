#ifndef _estructure_h_
#define _estructure_h_

#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

struct eif_ex_11 {union overhead overhead; char data [1];};
struct eif_ex_21 {union overhead overhead; char data [1];};
struct eif_ex_188 {union overhead overhead; char data [8];};
struct eif_ex_191 {union overhead overhead; char data [8];};
struct eif_ex_194 {union overhead overhead; char data [8];};
struct eif_ex_197 {union overhead overhead; char data [8];};
struct eif_ex_200 {union overhead overhead; char data [8];};
struct eif_ex_203 {union overhead overhead; char data [8];};
struct eif_ex_206 {union overhead overhead; char data [8];};
struct eif_ex_209 {union overhead overhead; char data [8];};
struct eif_ex_212 {union overhead overhead; char data [8];};
struct eif_ex_215 {union overhead overhead; char data [8];};
struct eif_ex_218 {union overhead overhead; char data [8];};
struct eif_ex_221 {union overhead overhead; char data [8];};
struct eif_ex_224 {union overhead overhead; char data [8];};
struct eif_ex_227 {union overhead overhead; char data [8];};
struct eif_ex_247 {union overhead overhead; char data [8];};
struct eif_ex_263 {union overhead overhead; char data [8];};
struct eif_ex_382 {union overhead overhead; char data [8];};
struct eif_ex_499 {union overhead overhead; char data [8];};
struct eif_ex_503 {union overhead overhead; char data [8];};
struct eif_ex_507 {union overhead overhead; char data [8];};
struct eif_ex_514 {union overhead overhead; char data [8];};
struct eif_ex_599 {union overhead overhead; char data [8];};
struct eif_ex_605 {union overhead overhead; char data [8];};
struct eif_ex_636 {union overhead overhead; char data [8];};
struct eif_ex_857 {union overhead overhead; char data [8];};
struct eif_ex_867 {union overhead overhead; char data [8];};
struct eif_ex_873 {union overhead overhead; char data [8];};
struct eif_ex_879 {union overhead overhead; char data [8];};
struct eif_ex_902 {union overhead overhead; char data [8];};
struct eif_ex_980 {union overhead overhead; char data [1];};
struct eif_ex_982 {union overhead overhead; char data [1];};
struct eif_ex_990 {union overhead overhead; char data [1];};
struct eif_ex_992 {union overhead overhead; char data [32];};
struct eif_ex_997 {union overhead overhead; char data [1];};
struct eif_ex_1231 {union overhead overhead; char data [16];};

#ifdef __cplusplus
}
#endif
#endif

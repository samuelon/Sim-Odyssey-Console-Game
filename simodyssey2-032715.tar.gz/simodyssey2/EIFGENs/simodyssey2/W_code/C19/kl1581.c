/*
 * Code for class KL_WINDOWS_OUTPUT_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"


#ifdef __cplusplus
extern "C" {
#endif

extern EIF_TYPED_VALUE F1581_15932(EIF_REFERENCE);
extern void EIF_Minit1581(void);

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_WINDOWS_OUTPUT_FILE}.eol */
RTOID (F1581_15932)


EIF_TYPED_VALUE F1581_15932 (EIF_REFERENCE Current)
{
	GTCX
	RTOTC (F1581_15932,22166,RTMS_EX_H("\015\012",2,3338));
}

void EIF_Minit1581 (void)
{
	GTCX
	RTOTS (15932,F1581_15932)
}


#ifdef __cplusplus
}
#endif

/*
 * Code for class EV_DOCKABLE_TARGET_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"


#ifdef __cplusplus
extern "C" {
#endif

extern void EIF_Minit1429(void);

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

void EIF_Minit1429 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif

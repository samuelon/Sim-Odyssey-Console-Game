/*
 * Code for class EV_GTK_ENUMS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"


#ifdef __cplusplus
extern "C" {
#endif

extern EIF_TYPED_VALUE F964_7239(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7240(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7241(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7242(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7243(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7244(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7245(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7246(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7247(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7248(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7249(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7250(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7251(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7252(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7253(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7254(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7255(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7256(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7257(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7258(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7259(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7260(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7261(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7262(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7263(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7264(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7265(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7266(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7267(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7268(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7269(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7270(EIF_REFERENCE);
extern EIF_TYPED_VALUE F964_7271(EIF_REFERENCE);
extern void EIF_Minit964(void);

#ifdef __cplusplus
}
#endif

#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GTK_ENUMS}.gdk_window_type_hint_toolbar_enum */
EIF_TYPED_VALUE F964_7239 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_window_type_hint_toolbar_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13569);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13569);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_WINDOW_TYPE_HINT_TOOLBAR;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_window_type_hint_utility_enum */
EIF_TYPED_VALUE F964_7240 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_window_type_hint_utility_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13570);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13570);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_WINDOW_TYPE_HINT_UTILITY;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gtk_toplevel_enum */
EIF_TYPED_VALUE F964_7241 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gtk_toplevel_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13571);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13571);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GTK_TOPLEVEL;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gtk_no_window_enum */
EIF_TYPED_VALUE F964_7242 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gtk_no_window_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13539);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13539);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GTK_NO_WINDOW;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gtk_can_default_enum */
EIF_TYPED_VALUE F964_7243 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gtk_can_default_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13540);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13540);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GTK_CAN_DEFAULT;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gtk_has_default_enum */
EIF_TYPED_VALUE F964_7244 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gtk_has_default_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13541);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13541);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GTK_HAS_DEFAULT;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gtk_receives_default_enum */
EIF_TYPED_VALUE F964_7245 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gtk_receives_default_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13542);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13542);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GTK_RECEIVES_DEFAULT;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_nothing_enum */
EIF_TYPED_VALUE F964_7246 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_nothing_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13543);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13543);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_NOTHING;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_delete_enum */
EIF_TYPED_VALUE F964_7247 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_delete_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13544);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13544);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_DELETE;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_destroy_enum */
EIF_TYPED_VALUE F964_7248 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_destroy_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13545);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13545);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_DESTROY;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_expose_enum */
EIF_TYPED_VALUE F964_7249 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_expose_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13546);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13546);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_EXPOSE;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_motion_notify_enum */
EIF_TYPED_VALUE F964_7250 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_motion_notify_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13547);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13547);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_MOTION_NOTIFY;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_button_press_enum */
EIF_TYPED_VALUE F964_7251 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_button_press_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13548);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13548);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_BUTTON_PRESS;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_2button_press_enum */
EIF_TYPED_VALUE F964_7252 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_2button_press_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13549);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13549);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_2BUTTON_PRESS;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_3button_press_enum */
EIF_TYPED_VALUE F964_7253 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_3button_press_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13550);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13550);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_3BUTTON_PRESS;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_button_release_enum */
EIF_TYPED_VALUE F964_7254 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_button_release_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13551);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13551);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_BUTTON_RELEASE;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_key_press_enum */
EIF_TYPED_VALUE F964_7255 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_key_press_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13552);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13552);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_KEY_PRESS;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_key_release_enum */
EIF_TYPED_VALUE F964_7256 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_key_release_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13553);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13553);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_KEY_RELEASE;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_enter_notify_enum */
EIF_TYPED_VALUE F964_7257 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_enter_notify_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13554);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13554);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_ENTER_NOTIFY;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_leave_notify_enum */
EIF_TYPED_VALUE F964_7258 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_leave_notify_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13555);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13555);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_LEAVE_NOTIFY;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_focus_change_enum */
EIF_TYPED_VALUE F964_7259 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_focus_change_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13556);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13556);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_FOCUS_CHANGE;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_configure_enum */
EIF_TYPED_VALUE F964_7260 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_configure_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13557);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13557);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_CONFIGURE;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_map_enum */
EIF_TYPED_VALUE F964_7261 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_map_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13558);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13558);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_MAP;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_unmap_enum */
EIF_TYPED_VALUE F964_7262 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_unmap_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13559);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13559);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_UNMAP;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_proximity_in_enum */
EIF_TYPED_VALUE F964_7263 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_proximity_in_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13560);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13560);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_PROXIMITY_IN;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_proximity_out_enum */
EIF_TYPED_VALUE F964_7264 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_proximity_out_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13561);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13561);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_PROXIMITY_OUT;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_watch_enum */
EIF_TYPED_VALUE F964_7265 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_watch_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13562);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13562);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_WATCH;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_xterm_enum */
EIF_TYPED_VALUE F964_7266 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_xterm_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13563);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13563);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_XTERM;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_crosshair_enum */
EIF_TYPED_VALUE F964_7267 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_crosshair_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13564);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13564);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_CROSSHAIR;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_question_arrow_enum */
EIF_TYPED_VALUE F964_7268 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_question_arrow_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13565);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13565);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_QUESTION_ARROW;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_left_ptr_enum */
EIF_TYPED_VALUE F964_7269 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_left_ptr_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13566);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13566);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_LEFT_PTR;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_fleur_enum */
EIF_TYPED_VALUE F964_7270 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_fleur_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13567);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13567);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_FLEUR;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

/* {EV_GTK_ENUMS}.gdk_size_sb_v_double_arrow_enum */
EIF_TYPED_VALUE F964_7271 (EIF_REFERENCE Current)
{
	GTCX
	char *l_feature_name = "gdk_size_sb_v_double_arrow_enum";
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTSN;
	RTDA;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	RTLU (SK_INT32, &Result);
	RTLU (SK_REF, &Current);
	
	RTEAA(l_feature_name, 963, Current, 0, 0, 13568);
	RTSA(dtype);
	RTSC;
	RTME(dtype, 1);
	RTDBGEAA(963, Current, 13568);
	RTIV(Current, RTAL);
	Result = (EIF_INTEGER_32) GDK_SB_V_DOUBLE_ARROW;
	RTVI(Current, RTAL);
	RTRS;
	RTHOOK(1);
	RTDBGLE;
	RTMD(1);
	RTLE;
	RTLO(2);
	RTEE;
	{ EIF_TYPED_VALUE r; r.type = SK_INT32; r.it_i4 = Result; return r; }
}

void EIF_Minit964 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
